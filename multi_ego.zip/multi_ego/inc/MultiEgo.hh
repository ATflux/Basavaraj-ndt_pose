/* ======================================================
 *  file:       MultiEgo.hh
 * ---------------------------------------------------
 *  purpose:	plugin of VIRES Multi Ego Control
 * ---------------------------------------------------
 *  first edit:	20.02.2022 by Basavaraj P Narasapur @ Flux Auto
 * =====================================================
 */
#ifndef _MULTI_EGO_HH
#define _MULTI_EGO_HH
/* ====== INCLUSIONS ====== */
#include <string>
#include "DynamicsPlugin.hh"
#include <memory>
#include "SensorPlugin.hh"
#include "ScpParser.hh"
#include <ros/ros.h>
#include "std_msgs/String.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Twist.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Bool.h"
#include "std_msgs/String.h"
#include "std_msgs/MultiArrayLayout.h"
#include "std_msgs/MultiArrayDimension.h"
#include "std_msgs/Float32MultiArray.h"
#include <tf/transform_datatypes.h>
#include <signal.h>
#include <math.h>
#include "v2x_msgs/v2x_msg.h"
#include "v2x_msgs/objectArray.h"
#include "flux_msgs/RegisterBOPT.h"
#include "flux_msgs/Goal.h"
#include <tf/transform_broadcaster.h>


#include <string>

// forward declaration
namespace Module
{

    // forward declarations
    class DynamicsIface;

    class MultiEgo : public Module::DynamicsPlugin
    {
    public:
        /**
         * factory function for creating a new object, derived from ParamIface
         */
        static Framework::Plugin *makeModule();

    public:
        /**
         * constructor
         **/
        explicit MultiEgo();

        /**
         * Destroy the class.
         */
        virtual ~MultiEgo();

        /**
         * initialize interface
         * @return success/failure
         */
        virtual bool init();

        /**
         * reset the plugin (called e.g. after re-start of simulation)
         * @param    simTime the simulation time used as reset time
         * @return true if successful
         */
        virtual bool reset(const double &simTime);

        /**
         * handle an incoming dynamics message
         * @param frameNo     the current frame number
         * @param ifaceData   dynamics interface data
         * @return return code
         */
        virtual int update(const unsigned long &frameNo, DynamicsIface *ifaceData);
        

        /**
         * Reads ModuleManager.xml and also simulation SCP
         * @param cmd  scp commands
         * @return return success/failure
         */
        virtual bool handleSCPElement(Framework::ScpParser* cmd);

        /**
         * Ros initilize function
         * @return return success/failure
         */

        bool InitializeROS(); 

        /**
         * Handle an incoming ros throttle callback message
         * @param msg the incoming message
         * @return return void
         */
        void kThrottlePedalCallback(const std_msgs::Float32::ConstPtr &msg);

        /**
         * Handle an incoming ros speed callback message
         * @param msg the incoming message
         * @return return void
         */
        void kSpeedTgtCallback(const std_msgs::Float32::ConstPtr &msg);
        void kSteeringTgtCallback(const std_msgs::Float32::ConstPtr &msg);
        void kBrakeTgtCallback(const std_msgs::Float32::ConstPtr &msg);
        void kManualCtrlCallback(const std_msgs::Bool::ConstPtr &msg);
        bool kServicecallBack(flux_msgs::RegisterBOPT::Request &req, flux_msgs::RegisterBOPT::Response &res);

        /**
         * Copy messages from VTD to ROS
         * @param RDB_OBJECT_STATE_t
         * @return void
        */
        template<typename T>
        void kCopyVTDtoRos(const T *objState ){
            tf::Quaternion quat = tf::createQuaternionFromRPY(objState->base.pos.r, objState->base.pos.p, objState->base.pos.h);
            tf::Quaternion q = tf::createQuaternionFromRPY(kr, kp, kh);
   
            kglobalPoseMsgs.bopt_goal.pose.position.x = kx;
            kglobalPoseMsgs.bopt_goal.pose.position.y = ky;
            kglobalPoseMsgs.bopt_goal.pose.position.z = kz;
            kglobalPoseMsgs.bopt_goal.pose.orientation.x = q.x();
            kglobalPoseMsgs.bopt_goal.pose.orientation.y = q.y();
            kglobalPoseMsgs.bopt_goal.pose.orientation.z = q.z();
            kglobalPoseMsgs.bopt_goal.pose.orientation.w = q.w();
            kglobalPoseMsgs.bopt_id = std::to_string(mPlayerId);

            kndtMsgs.header.seq++;
            kndtMsgs.header.stamp = clock;
            kndtMsgs.header.frame_id = "ndt_pose";
        
            kndtMsgs.pose.position.x =  objState->base.pos.x;
            kndtMsgs.pose.position.y =  objState->base.pos.y;
            kndtMsgs.pose.position.z =  objState->base.pos.z;
            kndtMsgs.pose.orientation.x = quat.x();
            kndtMsgs.pose.orientation.y = quat.y();
            kndtMsgs.pose.orientation.z = quat.z();
            kndtMsgs.pose.orientation.w = quat.w();
            
            //publishing the transform
            // static tf::TransformBroadcaster br1;
            // tf::Transform transform1;
            // // transform1.setOrigin(tf::Vector3(objState->base.pos.x, objState->base.pos.y, 0.0));
            // transform1.setOrigin(tf::Vector3(0.0, 0.0, 0.0));
            // quat.setRPY(0, 0, objState->base.pos.h);
            // transform1.setRotation(quat);
            // br1.sendTransform(tf::StampedTransform(transform1, ros::Time::now(), "map", "ndt_pose"));
            
        }
        double prev_x = 0.0, prev_y = 0.0;
        double vel_x = 0.0, vel_y= 0;
        bool ok = false;
        bool updateOnce = true;
        /**
         * calculate speed from position
         * @param x pose x
         * @param y pose y
         * @param sim_time sim time for calculating deltaT
         * @return void
         */
        void 
        KPrevMemPoseState(const double &x_, const double &y_, double sim_time){
            if (!ok)
            {
                prev_x = x_; // get the first sim update
                prev_y = y_;
                ok = true;
            }
            else{
                vel_x = (x_ - prev_x)/MultiEgo::mDeltaSimTime;
                vel_y = (y_ - prev_y)/MultiEgo::mDeltaSimTime;
                prev_x = x_;
                prev_y = y_;
            }
        }       
        /**
         * update message header
         * @param time
         * @param parent_frame
         * @param msg
         * @return void
         */
        template <typename Input>
        void setHeaderFields(const ::ros::Time &time, const char *parent_frame, Input &input)
        {
            input->header.frame_id = parent_frame;
            input->header.stamp = time;
        }
        /**
         * Reads subscriber topic from modulemanger.xml
         * @return return void
         */
        void handleSubscriberSCPElement(){
            if (cmd_->getCurrentElementName() == "RosSubscriberTopic")
            {
                if (cmd_->hasAttribute("throttle_topic"))
                {
                    std::string pid;
                    pid = cmd_->getString("throttle_topic");
                    kThrottlePedalTopic = pid;
                }
                if (cmd_->hasAttribute("speed_topic"))
                {
                    std::string pid;
                    pid = cmd_->getString("speed_topic");
                    kSpeedTopic = pid;
                }
                if (cmd_->hasAttribute("steering_topic"))
                {
                    std::string pid;
                    pid = cmd_->getString("steering_topic");
                    kSteeringTopic = pid;
                }
                if (cmd_->hasAttribute("brake_topic"))
                {
                    std::string pid;
                    pid = cmd_->getString("brake_topic");
                    kBrakeTopic = pid;
                }
                if (cmd_->hasAttribute("manual_ctrl"))
                {
                    std::string pid;
                    pid = cmd_->getString("manual_ctrl");
                    kManualCtrlTopic = pid;
                }
            }
        }
        /**
         * Reads publisher topic from modulemanger.xml
         * @return return void
         */
        void handlePublisherSCPElement(){
            if (cmd_->getCurrentElementName() == "RosPublisherTopic")
            {

                if (cmd_->hasAttribute("ndt_pose"))
                {
                    std::string pid;
                    pid = cmd_->getString("ndt_pose");
                    kndt_pose = pid;
                }
                // if (cmd_->hasAttribute("global_pose"))
                // {
                //     std::string pid;
                //     pid = cmd_->getString("global_pose");
                //     kglobal_pose = pid;
                // }
                // if (cmd_->hasAttribute("ego_speed"))
                // {
                //     std::string pid;
                //     pid = cmd_->getString("ego_speed");
                //     kego_speed = pid;
                // }

                // if (cmd_->hasAttribute("obj_info"))
                // {
                //     std::string pid;
                //     pid = cmd_->getString("obj_info");
                //     kobj_info = pid;
                // }
        
            }
        }
        /**
         * Reads Ego goal info from modulemanger.xml
         * @return return void
         */
        void handleEgoGoalSCPElement(){
            if (cmd_->getCurrentElementName() == "EgoDestination")
            {

                if (cmd_->hasAttribute("x"))
                {
                    std::string pid;
                    pid = cmd_->getString("x");
                    kx = std::stof(pid);
                }
                if (cmd_->hasAttribute("y"))
                {
                    std::string pid;
                    pid = cmd_->getString("y");
                    ky = std::stof(pid);
                }
                if (cmd_->hasAttribute("z"))
                {
                    std::string pid;
                    pid = cmd_->getString("z");
                    kz = std::stof(pid);
                }
                if (cmd_->hasAttribute("r"))
                {
                    std::string pid;
                    pid = cmd_->getString("r");
                    kr = std::stof(pid);
                }
                if (cmd_->hasAttribute("p"))
                {
                    std::string pid;
                    pid = cmd_->getString("p");
                    kp = std::stof(pid);
                }
                if (cmd_->hasAttribute("h"))
                {
                    std::string pid;
                    pid = cmd_->getString("h");
                    kh = std::stof(pid);
                }
            }
        }
        /**
         * Ego direction info from modulemanger.xml
         * @return return void
         */
        void handleEgoDirectionSCPElement(){
            if (cmd_->getCurrentElementName() == "EgoDirection")
            {

                if (cmd_->hasAttribute("direction"))
                {
                    std::string pid;
                    pid = cmd_->getString("direction");
                    kego_direction = pid;
                }
                if (cmd_->hasAttribute("emergency"))
                {
                    std::string pid;
                    pid = cmd_->getString("emergency");
                    kego_emergency = pid;
                }
            }
        }
        /**
         * Reads node name and id topic from modulemanger.xml
         * @return return success/failure
         */

        void handleNodeAndPlayerIdSCPElement(){
            if (cmd_->getCurrentElementName() == "Player")
            {
                if (cmd_->hasAttribute("id"))
                {
                    unsigned int pid;
                    pid = cmd_->getUInt("id");
                    mPlayerId = pid;
                }
            }

            if (cmd_->getCurrentElementName() == "RosNode")
            {
                if (cmd_->hasAttribute("node_name"))
                {
                    std::string pid;
                    pid = cmd_->getString("nodeName");
                    mNodeName = pid;
                }
            }
        }

        /**
         * This function reset the ros params
         * @return void
         */
        void ResetROS();

        /**
         * Signal interupt handler
         * @param sig the interupt
         * @return return void
         */

        static void mySigintHandler(int sig);

    private:
        /**
         * compute the ouptut data from given input data
         */
        void computeOutput();

    private:
        /**
         * remember previous frame number
         */
        unsigned long mLastFrameNo;

        /**
         * player ID which is to be used
         */
  
        unsigned int mPlayerId;
        
        ros::Time clock;
        bool mEnableManualCtrl = false;
        bool mSendSCP = false;
        Framework::ScpParser *cmd_;
        /**
         * driver inputs
         */

        float steeringWheel;
        float mThrottlePedal;
        double mOwnSpeed;
        float mBrakePedal;
        float MAX_DECELERATION = 0.8f;
        bool direction;
        bool prev_dir;
        bool emergency_stop;
        bool mchange_direction_reverse;
        bool mchange_direction_forwared;
        double egox;
        double egoy;
       

        /**
         * ROS messages
         */
        std_msgs::Float32 kThrottlePedalMsg;
        std_msgs::Float32 kSpeedMsg;
        std_msgs::Float32 kSteeringMsg;
        std_msgs::Float32 kBrakeMsg;
        std_msgs::Bool kManualCtrlMsg;
        v2x_msgs::v2x_msg kv2xMsg;
        
        flux_msgs::Goal kglobalPoseMsgs;
        
        std_msgs::Float32 kegoSpeedMsgs;
        v2x_msgs::objectArray kobjInfoMsgs;
        geometry_msgs::PoseStamped kndtMsgs;

        /**
         * ROS services
         */       
        flux_msgs::RegisterBOPT srv;
      
        /**
         * Throttle topic
         */
        std::string kThrottlePedalTopic;

        /**
         * Speed topic
         */
        std::string kSpeedTopic;
        /**
         * Steering topic
         */
        std::string kSteeringTopic;
        /**
         * Brake topic
         */
        std::string kBrakeTopic;
        /**
         * Manual Control topic
         */
        std::string kManualCtrlTopic;
        /**
         * v2xmsgs topic
         */
        std::string kv2xTopic;
        /**
         * ndt_pose topic
         */
        std::string kndt_pose;
        /**
         * global pose topic
         */
        std::string kglobal_pose;
        /**
         * global pose topic
         */
        std::string kego_speed;
        /**
         * obj pose topic
         */
        std::string kobj_info;
        /**
         * Ego direction
         */
        std::string kego_direction;
        /**
         * Ego emergency stop
         */
        std::string kego_emergency;

        /**
         * Ego Destination
        */ 
        double kx, ky, kz, kr, kp, kh;
        /**
         * Ros Subscribers
        */
        ros::Subscriber kThrottlePedalSubscriber;
        ros::Subscriber kSpeedSubscriber;
        ros::Subscriber kSteeringSubscriber;
        ros::Subscriber kBrakeSubscriber;
        ros::Subscriber kManualCtrlSubscriber;
        /**
         * Ros Publisher
         */



        ros::Publisher kndtPose;

        ros::Publisher kglobalPose;

        // ros::Publisher kEgoSpeed;
        // ros::Publisher kobjInfo;

         /**
         * Ros service
         */

        ros::ServiceClient client;
       
         /**
         * Node handleres
         */
        std::unique_ptr<ros::NodeHandle> node_;

        /**
         * Node AsyncSpinner
         */
        std::unique_ptr<ros::AsyncSpinner> spinner_;
        
        /**
         * Node name
        */
        std::string mNodeName;

        /**
         * Intilize all subscriber/publisher/service call back.
         * @return return success/failure
         */
        bool InitlizeSubscribers();
        bool InitlizePublishers();
        bool InitlizeServices();


        
    };
} // namespace Module
#endif /* _MULTI_EGO_HH */
