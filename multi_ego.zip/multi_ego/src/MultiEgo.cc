/* ===========================================================
 *  file:       MultiEgo.cc
 * ---------------------------------------------------
 *  purpose:	the plugin of a Multi Ego driver
 * ---------------------------------------------------
 *  first edit:	20.02.2022 by Basavaraj P Narasapur @ Flux Auto
 * ============================================================
 */
/* ====== INCLUSIONS ====== */
#include <math.h>
#include <iostream>
#include "DynamicsIface.hh"
#include "MultiEgo.hh"
#include <stdlib.h>
#include <stdio.h>
#include "SensorIface.hh"
#include "flux_msgs/RegisterBOPT.h"


// actual class declaration for access via shared mechanisms
// is hidden behind this little function; make sure, this
// function is included in all data accesss libraries
// @todo: make this a macro
extern "C"
{

    Framework::Plugin *
    makeModule()
    {
        return new Module::MultiEgo();
    }
} // extern "C"

namespace Module
{

    MultiEgo::MultiEgo() : mLastFrameNo(0),
                                 mPlayerId(0),
                                 steeringWheel(0.0f),
                                 mThrottlePedal(0.0f),
                                 mOwnSpeed(0.0),
                                 mBrakePedal(0.0f),
                                 mchange_direction_reverse(true),
                                 mchange_direction_forwared(true)
                           
    {
        MultiEgo::InitializeROS();
     
    }

    MultiEgo::~MultiEgo()
    {
        // std::cerr << "MultiEgo: DTOR called, this=" << this << std::endl;
        fprintf(stderr, "MultiEgo::~MultiEgo() called\n");
        // node_->stop();

    }

    void 
    MultiEgo::mySigintHandler(int sig)
    {
        // All the default sigint handler does is call shutdown()
        // MultiEgo::ResetROS();
        fprintf(stderr, "MultiEgo::mySigintHandler() called\n");
        ros::shutdown();
    }

    bool 
    MultiEgo::InitializeROS()
    {
        fprintf(stderr, "MultiEgo::InitializeROS() called\n");
        // Initialize ROS
        int argc = 0;
        char **argv = NULL;
        ros::init(argc, argv, "master_multi_ego_node", ros::init_options::NoSigintHandler);

        // signal(SIGINT, std::bind(&MultiEgo::mySigintHandler,this,_1));
        signal(SIGTTOU, MultiEgo::mySigintHandler);
        node_.reset(new ros::NodeHandle());
        spinner_.reset(new ros::AsyncSpinner(2));
        spinner_->start();
        return true;
    }
    bool
    MultiEgo::InitlizeSubscribers(){
        kThrottlePedalSubscriber = node_->subscribe(kThrottlePedalTopic, 10, &MultiEgo::kThrottlePedalCallback, this);
        kSpeedSubscriber = node_->subscribe(kSpeedTopic, 10, &MultiEgo::kSpeedTgtCallback, this);
        kSteeringSubscriber = node_->subscribe(kSteeringTopic, 10, &MultiEgo::kSteeringTgtCallback, this);
        kBrakeSubscriber = node_->subscribe(kBrakeTopic, 10, &MultiEgo::kBrakeTgtCallback, this);
        kManualCtrlSubscriber = node_->subscribe(kManualCtrlTopic, 10, &MultiEgo::kManualCtrlCallback, this);
        return true;
    }

    bool
    MultiEgo::InitlizePublishers()
    {
        // kv2xPublisher = node_->advertise<v2x_msgs::v2x_msg>(kv2xTopic, 10);
        kglobalPose = node_->advertise<flux_msgs::Goal>("/vehicle_goals", 10);
        kndtPose = node_->advertise<geometry_msgs::PoseStamped>(kndt_pose, 10);
        // kEgoSpeed = node_->advertise<std_msgs::Float32>(kego_speed, 10);
        // kobjInfo = node_->advertise<v2x_msgs::objectArray>(kobj_info, 10);
        return true;
    }

    bool
    MultiEgo::InitlizeServices()
    {
       
        client = node_->serviceClient<flux_msgs::RegisterBOPT>("/register_BOPT");
        

        return true;
    }

    bool
    MultiEgo::init()
    {
        fprintf(stderr, "MultiEgo::init called\n");
        return true;
    }

    bool
    MultiEgo::reset(const double &simTime)
    {
        // first call reset routine of base class
        fprintf(stderr, "MultiEgo::reset: called\n");
        DynamicsPlugin::reset(simTime);
        mPlayerId = mPlayerId;
        steeringWheel = 0.0f;
        mThrottlePedal = 0.0f;
        mOwnSpeed = 0.0;
        mBrakePedal = 0.0f;


        return true;
    }


    void 
    MultiEgo::ResetROS(){
        fprintf(stderr, "MultiEgo::InitializeROS() called\n");
        ros::shutdown();
        spinner_->stop() ;
    }

    bool 
    MultiEgo::handleSCPElement(Framework::ScpParser *cmd)
    {
        cmd_ = cmd;
        handleSubscriberSCPElement();
        handlePublisherSCPElement();
        handleEgoGoalSCPElement();
        handleEgoDirectionSCPElement();
        handleNodeAndPlayerIdSCPElement();
        
        if (cmd->getCurrentElementName() == "Config"){
            MultiEgo::ResetROS();
        }
        MultiEgo::InitlizeSubscribers();
        MultiEgo::InitlizePublishers();
        MultiEgo::InitlizeServices();
        return true;
    }

    void 
    MultiEgo::kThrottlePedalCallback(const std_msgs::Float32::ConstPtr &msg)
    {
        kThrottlePedalMsg.data = msg->data;    
    }

    // void
    // MultiEgo::kSpeedTgtCallback(const geometry_msgs::Twist::ConstPtr &msg)
    // {
    //     float speed = static_cast<float>(sqrt(msg->linear.x * msg->linear.x + msg->linear.y * msg->linear.y));
    //     kSpeedMsg.data = speed;
    // }
    void
    MultiEgo::kSpeedTgtCallback(const std_msgs::Float32::ConstPtr &msg)
    {
        // float speed = static_cast<float>(sqrt(msg->linear.x * msg->linear.x + msg->linear.y * msg->linear.y));
        kSpeedMsg.data = msg->data;
    }

    void
    MultiEgo::kSteeringTgtCallback(const std_msgs::Float32::ConstPtr &msg)
    {
        kSteeringMsg = *msg;
    }

    void
    MultiEgo::kBrakeTgtCallback(const std_msgs::Float32::ConstPtr &msg)
    {
        kBrakeMsg = *msg;
    }
    void
    MultiEgo::kManualCtrlCallback(const std_msgs::Bool::ConstPtr &msg)
    {
        // std::cout<<"Manual Ctrl " << mPlayerId << ": "<< *msg << std::endl; 
        kManualCtrlMsg = *msg;
    }

    int
    MultiEgo::update(const unsigned long &frameNo, DynamicsIface *ifaceData)
    {
        // if (!ifaceData || (mOwnPlayerId < 0))
        //     return 0;
        
        kobjInfoMsgs.obj_distance.clear();
        clock = ros::Time::now(); //update ros time
       
        if (!mNewFrame)
            return 0;
       
        /* PART 1: collect and analyze incoming objects etc. --------------------------------------------------- */
        ModuleIface::DataMap::iterator srcMapIt;

        // get pointer to object data vector
        if ((srcMapIt = ifaceData->getDataMap().find(RDB_PKG_ID_OBJECT_STATE)) == ifaceData->getDataMap().end())
            return 0;
        ModuleIface::DataVec *srcVec = srcMapIt->second;  
 
        // std::cout << kego_direction << std::endl;
        if (node_->getParam(kego_direction, direction))
        {
            ROS_INFO("Got param: %d", direction);
        }
        else
        {
            ROS_ERROR("Failed to get param '/PP/direction'");
        }     
        if (node_->getParam(kego_emergency, emergency_stop))
        {
            ROS_INFO("Got param: %d", emergency_stop);
        }
        else
        {
            ROS_ERROR("Failed to get param '/emergency_stop'");
        } 

        srv.request.bopt_id.data = std::to_string(mPlayerId);
        srv.request.action_server_name.data =  "NA";
        
        if(!srv.response.register_status.data )
        {
     
            if (client.call(srv) )
            {
                ROS_INFO("\nRegistration status: %d\n",srv.response.register_status.data);
            }
            else
            {
                ROS_ERROR("\nFailed to call service registorBopt\n");
            }  
        }
        for (ModuleIface::DataVec::iterator srcVecIt = srcVec->begin(); srcVecIt != srcVec->end(); srcVecIt++)
        {
            ModuleIface::DataEntry *srcEntry = (*srcVecIt);
            RDB_OBJECT_STATE_t *objState = (RDB_OBJECT_STATE_t *)(srcEntry->data);

         
            if (objState->base.id == mPlayerId)
            {        
                egox = objState->base.pos.x;         
                egoy = objState->base.pos.y;         
                mOwnSpeed = sqrt(objState->ext.speed.x * objState->ext.speed.x + objState->ext.speed.y * objState->ext.speed.y)*3.6;
                // std::cout << "Speed: " << mOwnSpeed << std::endl;
                kCopyVTDtoRos(objState); // convert vtd to ros messages
                // kv2xPublisher.publish(kv2xMsg);
                // if(srv.response.register_status.data)
                //     kndtPose.publish(kndtMsgs);
                kndtPose.publish(kndtMsgs);
                kegoSpeedMsgs.data = static_cast<float>(mOwnSpeed/3.6);
                // kEgoSpeed.publish(kegoSpeedMsgs);
                
                // if(updateOnce){
                //      kglobalPose.publish(kglobalPoseMsgs);
                //      updateOnce = false;
                // }
                kglobalPose.publish(kglobalPoseMsgs);
               
                            
            }
            
            // if(objState->base.id != mPlayerId){
                
            //     float dist =static_cast<float> (sqrt( pow((egox-objState->base.pos.x),2) + pow((egoy-objState->base.pos.y),2) ));
            //     std_msgs::Float32 t;
            //     t.data = dist;
               
            //     //dist.data = sqrt( pow((egox-objState->base.pos.x),2) + pow((egoy-objState->base.pos.y),2) );
            //     kobjInfoMsgs.obj_distance.push_back(t);
            //     //std::cout << "Dist from Ego"<< mPlayerId << " : " << dist << std::endl;
            // }
            
        }

        // kobjInfo.publish(kobjInfoMsgs); //publishing object info relative to Ego
    
        /* PART 2: compose and send the feedback, i.e. the driver commands --------------------------------------------------- */

  
        RDB_MSG_t *msg = 0;

        RDB_DRIVER_CTRL_t *pInsData = (RDB_DRIVER_CTRL_t *)ModulePlugin::RDBaddPackage(ifaceData->mSimTime, static_cast<unsigned int>(ifaceData->mFrameNo), msg, RDB_PKG_ID_DRIVER_CTRL, 1);
       
        if (!pInsData || !msg)
            return 0;
        pInsData->playerId = mPlayerId;


        // pInsData->steeringWheel = kSteeringMsg.data;
        pInsData-> steeringTgt = kSteeringMsg.data;
        pInsData->validityFlags = RDB_DRIVER_INPUT_VALIDITY_ADD_ON | RDB_DRIVER_INPUT_VALIDITY_TGT_STEERING | RDB_DRIVER_INPUT_VALIDITY_GEAR | RDB_DRIVER_INPUT_VALIDITY_TGT_ACCEL | RDB_DRIVER_INPUT_VALIDITY_BRAKE;
   
        if (!(kThrottlePedalMsg.data > 0 && kSpeedMsg.data > 0))
        { 
            if (kThrottlePedalMsg.data > 0.0 || kThrottlePedalMsg.data < 0.0){
                pInsData->accelTgt = kThrottlePedalMsg.data;
                
            }
            if(kSpeedMsg.data >= 0.0 ){
                if(direction){

                    pInsData->gear = RDB_GEAR_BOX_POS_D;
                    mchange_direction_reverse = true;
                    if(mchange_direction_forwared ) //
                    {  
                        pInsData->accelTgt = -100;
                       if(mOwnSpeed != 0.0) mchange_direction_forwared = true;
                       else mchange_direction_forwared = false;
                    }
                    else
                    {    
                        pInsData->accelTgt = static_cast<float>(kSpeedMsg.data - mOwnSpeed) / MAX_DECELERATION;
                    }
                    
                        
                }
                else {
                   
                    pInsData->gear = RDB_GEAR_BOX_POS_R;
                    mchange_direction_forwared = true;
                    if(mchange_direction_reverse ) //
                    {   
                       pInsData->accelTgt = -100;
                       if(mOwnSpeed != 0.0) mchange_direction_reverse = true;
                       else mchange_direction_reverse = false;
                    }
                    else 
                    { 
                        pInsData->accelTgt = static_cast<float>( kSpeedMsg.data - mOwnSpeed ) / MAX_DECELERATION;
                    }
                }

    
            }

           if (kBrakeMsg.data > 0)
            {
                pInsData->accelTgt = -1 * pInsData->accelTgt * kBrakeMsg.data;
            }
        }
 
        ModulePlugin::sendFeedback(msg, msg->hdr.headerSize + msg->hdr.dataSize);
        if(!mSendSCP)
        {
            MultiEgo::sendSCPMessage("<Symbol duration=\"2.0\" name=\" expl01 \" > <Text data=\"Autonomous OFF: " + ifaceData->getPlayerName(mPlayerId)+"\" colorRGB=\"0x2600fc\" size=\"50.0\" /> <PosScreen x=\"0.01\" y=\"0.05\" /></Symbol>");
            mSendSCP = true;
        }
    
        free(msg);

        mLastFrameNo = mFrameNo;
        
        // std::cout << ":End of update:" << std::endl;
        return 1;
    }
    

    } // namespace Module
